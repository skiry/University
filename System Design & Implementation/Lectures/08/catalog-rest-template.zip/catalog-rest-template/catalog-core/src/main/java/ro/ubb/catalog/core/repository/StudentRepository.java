package ro.ubb.catalog.core.repository;

import ro.ubb.catalog.core.model.Student;

/**
 * author: radu
 */
public interface StudentRepository extends CatalogRepository<Student, Long> {
}
