package ro.ubb.jdbc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * author: radu
 */
public class StudentRepository {
    private static final String URL = "jdbc:postgresql://localhost:5432/jdbc";
    private static final String USERNAME = System.getProperty("username");
    private static final String PASSWORD = System.getProperty("password");

    public StudentRepository() {
    }

    public List<Student> findAll() {
        List<Student> students = new ArrayList<>();
        String sql = "select * from Student";

        try (var connection = DriverManager.getConnection(URL, USERNAME,
                                                          PASSWORD);
             var statement = connection.prepareStatement(sql);
             var resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                int grade = resultSet.getInt("grade");

                students.add(new Student(id, name, grade));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public void save(Student s) {
        String sql = "insert into student(name,grade) values (?,?)";
        try (var connection = DriverManager.getConnection(URL, USERNAME,
                                                          PASSWORD);
             var statement = connection.prepareStatement(sql)) {

            statement.setString(1, s.getName());
            statement.setInt(2, s.getGrade());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void update(Student student) {
        String sql = "update student set name=?, grade=? where id=?";
        try (var connection = DriverManager.getConnection(URL, USERNAME,
                                                          PASSWORD);
             var statement = connection.prepareStatement(sql)) {

            statement.setString(1, student.getName());
            statement.setInt(2, student.getGrade());
            statement.setLong(3, student.getId());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Long id) {
        String sql = "delete from student where id=?";
        try (var connection = DriverManager.getConnection(URL, USERNAME,
                                                          PASSWORD);
             var statement = connection.prepareStatement(sql)) {

            statement.setLong(1, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
