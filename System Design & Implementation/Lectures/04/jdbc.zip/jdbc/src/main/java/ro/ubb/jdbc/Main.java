package ro.ubb.jdbc;

import java.util.List;

/**
 * author: radu
 */
public class Main {
    public static void main(String[] args) {

        StudentRepository repo = new StudentRepository();

        List<Student> all = repo.findAll();
        all.stream()
           .forEach(s -> System.out.println(s));

        //save
        Student s = new Student("Andrew", 7);
        repo.save(s);

        //update
        repo.update(new Student(all.get(0).getId(), "update", 10));
        System.out.println("after update:");
        all = repo.findAll();
        all.stream()
           .forEach(s1 -> System.out.println(s1));

        repo.delete(all.get(0).getId());
        System.out.println("after delete:");
        all = repo.findAll();
        all.stream()
           .forEach(s1 -> System.out.println(s1));


        System.out.println("bye");
    }
}
